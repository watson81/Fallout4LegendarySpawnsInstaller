The Iron Rose should add readme text for her mod here. I suggest basically copy-n-pasting the description text from Nexus.

Thanks to Patrick Watson (watson81) for the installation code.
